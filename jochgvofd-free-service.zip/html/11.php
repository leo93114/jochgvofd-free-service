<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<span style="font-family:Arial, Tahoma, Helvetica, FreeSans, Microsoft JhengHei, Heiti TC, TW-Kai, sans-serif;">
<html>
<head>
<title>次是慶宇HTML語法整理</title>
<link rel=stylesheet type="text/css" href="image/joch.css">
</head>
<body>
<p>
	<td><?php require_once('./image/header.php'); ?></td></p><div style="text-align: center;">
<a href="index.php"><img src="image/logo.png"></a>
</div>
<h1>文字格式化</h1>
<fieldset>
<div>
	用<span style="color:#cc00cc;">&lt;pre&gt;</span>的碼可以將你所要顯示的文字格式一模一樣的顯示在瀏覽器上，再用<span style="color:#9900ff;">&lt;/pre&gt;</span>來關閉</div>
<div>
	<span style="color:#cc00cc;">&lt;pre&gt;</span></div>
<div>
	格式會跟你打的一樣</div>
<div>
	會一模一樣</div>
<div>
	<span style="color:#9900ff;">&lt;/pre&gt;</span></div>
<pre>
格式會跟你打的一樣
會一模一樣
</pre>
</fieldset>
<a href="10.php" class="myButton"><img src="image/Back.gif" width="20" height="20"> 上一篇:強迫換行</a> <a href="12.php" class="myButton">下一篇:插入超連結 <img src="image/next.gif" width="20" height="20"></a>
</div>
<font size=5 color="#9900ff">
<td><?php require_once('./image/len.php'); ?></td></font>
</body>
</html>
</span>
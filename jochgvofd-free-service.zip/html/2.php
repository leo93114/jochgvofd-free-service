<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<span style="font-family:Arial, Tahoma, Helvetica, FreeSans, Microsoft JhengHei, Heiti TC, TW-Kai, sans-serif;">
<html>
<head>
<title>次是慶宇HTML語法整理</title>
<link rel=stylesheet type="text/css" href="image/joch.css">
</head>
<body>
<p>
	<td><?php require_once('./image/header.php'); ?></td></p><div style="text-align: center;">
<a href="index.php"><img src="image/logo.png"></a>
</div>
<h1>html的結構</h1>
<fieldset>
HTML document有一固定的格式，瀏覽器才可以辨識及分析，進而顯示在你的眼前，而基本格式為 :
<fieldset>
<div>
	<font color="#9999ff">&lt;html&gt;</font></div>
<div>
	<font color="#006600">&lt;head&gt;</font></div>
<div>
	<font color="#cc00cc">&lt;title&gt;</font></div>
<div>
	<font color="#cc00cc">&lt;/title&gt;</font></div>
<div>
	<font color="#006600">&lt;/head&gt;</font></div>
<div>
	<font color="#cc0066">&lt;body&gt;</font></div>
<div>
	您所要在瀏覽器顯示的內容</div>
<div>
	<font color="#cc0066">&lt;/body&gt;</font></div>
<div>
	<font color="#9999ff">&lt;/html&gt;</font></fieldset></div>
有兩個須要注意的地方，每一個開啟碼是由<font color="#006600">&lt;　&gt;</font> 兩個符號所框住的，而關閉碼是由<font color="#cc0066">&lt;/　&gt;</font> 所框住的，而每一個HTML碼有開就要有關，後面的單元會逐一的介紹。
</fieldset>
<a href="1.php" class="myButton"><img src="image/Back.gif" width="20" height="20"> 上一篇:概述html</a> <a href="3.php" class="myButton">下一篇:解決網頁亂碼 <img src="image/next.gif" width="20" height="20"></a>
</div>
<font size=5 color="#9900ff">
<td><?php require_once('./image/len.php'); ?></td>
</font>
</body>
</html>
</span>
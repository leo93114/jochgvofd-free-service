<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<span style="font-family:Arial, Tahoma, Helvetica, FreeSans, Microsoft JhengHei, Heiti TC, TW-Kai, sans-serif;">
<html>
<head>
<title>次是慶宇HTML語法整理</title>
<link rel=stylesheet type="text/css" href="image/joch.css">
</head>
<body>
<p>
	<td><?php require_once('./image/header.php'); ?></td></p><div style="text-align: center;">
<a href="index.php"><img src="image/logo.png"></a>
</div>
<h1>概述html</h1>
<fieldset>
HTML的全名是HyperText Markup Language，<br />是編寫網頁的基本語言，而它並不是一個程式，<br />只是一些插在普通文件內的碼( code )，<br />這些碼可以控制我們的瀏覽器要怎樣把文件顯示出來, 就是你現在所看到的頁面就是用HTML來控制的，<br />它可控制字體的大小，<br />也可以插入連結或圖像。<br />一個HTML檔稱為HTML document，<br />存檔的副檔名為htm或 html，<br />編寫的方式有很多種，<br />最原始的方法是用windows內的記事本或各種文書編輯軟體，<br />而現在有一種軟體也是編寫HTML碼，<br />但具有預覽及插入特效的功能，<br />如Dida 網頁速寫器，編寫完成後記得儲存成*.htm或*.html 即可。<br />若你想看一個網頁的HTML檔，只要在瀏覽器內按下滑鼠右鍵，再選擇 檢視原始檔(view)即可。<br />
一份標準的HTML文件是由元素所組成的，元素是由標籤(Tag)以及文件內容所組成。<br />文件內容可以是文字、圖形、甚至是影像、聲音等等。<br />而標籤又是啥東東呢？？ 一個開始標籤(< >)是由一個小於符號(<)和一個大於符號(>)所構成的 一個起始標籤中加一道斜線"/"就構成了結束標籤(</>) 而一對標籤是由一個起始標籤和一個結束標籤所構成的。
</fieldset>
<a href="index.php" class="myButton"><img src="image/Back.gif" width="20" height="20"> 返回教學導覽</a> <a href="2.php" class="myButton">下一篇:html的結構 <img src="image/next.gif" width="20" height="20"></a>
</div>
<font size=5 color="#9900ff">
<td><?php require_once('./image/len.php'); ?></td></font>
</body>
</html>
</span>
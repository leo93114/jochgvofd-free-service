<font size=5 color="#9900ff"><marquee direction="up" behavior="slide" bgcolor="#b76fff">
<div style="text-align: center;"><br />聯絡我們<br /><a href="mailto:jochgvofd@gmail.com"> <img src="image/taddyshen.png" /><br /><a href="https://line.me/ti/p/%40trr7250q"><img height="36" border="0" alt="好友人數" src="https://biz.line.naver.jp/line_business/img/btn/addfriends_zh-Hant.png" /></a><br /><a href="https://www.facebook.com/jochgvofdweb">Facebook粉絲團<a><br />
© 2012-2016 <a href="http://jochgvofd.com/" target="_blank">次是慶宇工作室</a> - © 2012-2016 <a href="http://wartw.com.tw" target="_blank">風雨人多元工作室</a>合作</a></a></a></div>

</marquee></font>
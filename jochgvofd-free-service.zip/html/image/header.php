<font size=5 color="#fff">
<marquee onMouseOver="this.stop()" onMouseOut="this.start()" bgcolor="#9900ff">次是慶宇html教學網正式開放，請使用新版瀏覽器效果更好。</marquee></font><a href="index.php" class="myButton"><img src="image/Back.gif" width="20" height="20"> 返回教學導覽</a> <a href="http://free.joch.gq/" class="myButton">更多免費服務</a> <a href="http://joch.gq/free/colorcobe" class="myButton">色碼表</a><!--[if lte IE 9]>
<center>
</p>
<p style="font-size: 16px;">
你目前使用舊版Internet Explorer瀏覽器，網頁會有異常哦
<p style="font-size: 16px;">
請換別的瀏覽器或更新IE瀏覽器以可獲得更好的體驗
<p><a href="http://www.google.com/chrome/" target="_blank"><img src="http://i.imgur.com/Ha8J2OQ.png" width="48" height="48" /></a> <a href="http://mozilla.com.tw/firefox/new/?utm_source=getfirefox-com&amp;utm_medium=referral" target="_blank"><img src="http://i.imgur.com/nb3Bx90.png" width="48" height="48" /></a> <a href="http://www.opera.com" target="_blank"><img src="http://i.imgur.com/qfywl6j.png" width="48" height="48" /></a> <a href="http://www.apple.com/cn/safari/" target="_blank"><img src="http://i.imgur.com/FSwXztz.png" width="48" height="48" /></a> <a href="http://windows.microsoft.com/zh-tw/internet-explorer/download-ie" target="_blank"><img src="http://i.imgur.com/vroljrQ.png" width="48" height="48" /></a></p>
</center>
</div>
<![endif]-->
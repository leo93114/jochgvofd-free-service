<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<span style="font-family:Arial, Tahoma, Helvetica, FreeSans, Microsoft JhengHei, Heiti TC, TW-Kai, sans-serif;">
<html>
<head>
<title>次是慶宇HTML語法整理</title>
<link rel=stylesheet type="text/css" href="image/joch.css">
</head>
<body>
<p>
	<td><?php require_once('./image/header.php'); ?></td></p><div style="text-align: center;">
<a href="index.php"><img src="image/logo.png"></a>
</div>
<h1>強迫換行</h1>
<fieldset>
<div>
	如果覺得您的文字太長，想要您的文字跳到下一行，就要加上<span style="color:#cc00cc;">&lt;br&gt;</span>的碼 :</div>
<div>
	斷行1<span style="color:#cc00cc;">&lt;br&gt;</span></div>
<div>
	斷行222</div>
<div>
	上面的碼會顯現強迫換行效果 :</div>
</fieldset>
<a href="9.php" class="myButton"><img src="image/Back.gif" width="20" height="20"> 上一篇:文字設定</a> <a href="11.php" class="myButton">下一篇:文字格式化 <img src="image/next.gif" width="20" height="20"></a>
</div>
<font size=5 color="#9900ff">
<td><?php require_once('./image/len.php'); ?></td></font>
</body>
</html>
</span>
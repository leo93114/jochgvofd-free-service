<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<span style="font-family:Arial, Tahoma, Helvetica, FreeSans, Microsoft JhengHei, Heiti TC, TW-Kai, sans-serif;">
<html>
<head>
<title>次是慶宇HTML語法整理</title>
<link rel=stylesheet type="text/css" href="image/joch.css">
</head>
<body>
<p>
	<td><?php require_once('./image/header.php'); ?></td></p><div style="text-align: center;">
<a href="index.php"><img src="image/logo.png"></a>
</div>
<h1>標題文字</h1>
<fieldset>
<div>
	瀏覽器可分出六種大小的標題文字,原始碼如下 :</div>
<div>
	<span style="color:#cc00cc;">&lt;h1&gt;</span>標題文字1<span style="color:#9900ff;">&lt;/h1&gt;</span></div>
<div>
	<span style="color:#cc00cc;">&lt;h2&gt;</span>標題文字2<span style="color:#9900ff;">&lt;/h2&gt;</span></div>
<div>
	<span style="color:#cc00cc;">&lt;h3&gt;</span>標題文字3<span style="color:#9900ff;">&lt;/h3&gt;</span></div>
<div>
	<span style="color:#cc00cc;">&lt;h4&gt;</span>標題文字4<span style="color:#9900ff;">&lt;/h4&gt;</span></div>
<div>
	<span style="color:#cc00cc;">&lt;h5&gt;</span>標題文字5<span style="color:#9900ff;">&lt;/h5&gt;</span></div>
<div>
	<span style="color:#cc00cc;">&lt;h6&gt;</span>標題文字6<span style="color:#9900ff;">&lt;/h6&gt;</span></div>
<div>
	上面的碼會造出下面六種大小的標題文字 :</div>
<h1>標題文字1</h1>
<h2>標題文字2</h2>
<h3>標題文字3</h3>
<h4>標題文字4</h4>
<h5>標題文字5</h5>
<h6>標題文字6</h6>
</fieldset>
<a href="7.php" class="myButton"><img src="image/Back.gif" width="20" height="20"> 上一篇:清單設定方式</a> <a href="9.php" class="myButton">下一篇:文字設定 <img src="image/next.gif" width="20" height="20"></a>
</div>
<font size=5 color="#9900ff">
<td><?php require_once('./image/len.php'); ?></td></font>
</body>
</html>
</span>
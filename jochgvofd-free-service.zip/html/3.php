<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<span style="font-family:Arial, Tahoma, Helvetica, FreeSans, Microsoft JhengHei, Heiti TC, TW-Kai, sans-serif;">
<html>
<head>
<title>次是慶宇HTML語法整理</title>
<style>
<link rel=stylesheet type="text/css" href="image/joch.css">
</style>
</head>
<body>
<p>
	<td><?php require_once('./image/header.php'); ?></td></p><div style="text-align: center;">
<a href="index.php"><img src="image/logo.png"></a>
</div>
<h1>解決網頁亂碼</h1>
<fieldset>
HTML或php，架設在你的虛擬主機，發生亂碼，解決方式用HTML語法就正常顯示字，基本格式
<fieldset>
<p>
	&lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;text/html; charset=utf-8&quot; /&gt;</p>
</fieldset>
</fieldset>
<a href="2.php" class="myButton"><img src="image/Back.gif" width="20" height="20"> 上一篇:html的結構</a> <a href="4.php" class="myButton">下一篇:網頁顏色設定 <img src="image/next.gif" width="20" height="20"></a>
</div>
<font size=5 color="#9900ff">
<td><?php require_once('./image/len.php'); ?></td></font>
</body>
</html>
</span>
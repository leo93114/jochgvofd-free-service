<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<span style="font-family:Arial, Tahoma, Helvetica, FreeSans, Microsoft JhengHei, Heiti TC, TW-Kai, sans-serif;">
<html>
<head>
<title>次是慶宇HTML語法整理</title>
<link rel=stylesheet type="text/css" href="image/joch.css">
<link href="//cdnjs.cloudflare.com/ajax/libs/alertify.js/0.3.10/alertify.core.css" rel="stylesheet">  
<link href="//cdnjs.cloudflare.com/ajax/libs/alertify.js/0.3.10/alertify.default.css" rel="stylesheet">  
<script src="//cdnjs.cloudflare.com/ajax/libs/alertify.js/0.3.10/alertify.min.js"></script>  
</head>
<body>
<p>
	<a href="index.php" class="myButton"><img src="image/Back.gif" width="20" height="20"> 返回目錄</a> <a href="http://free.joch.gq/" class="myButton">更多免費服務</a> <a href="http://free.joch.gq/colorcobe" class="myButton">色碼表</a></p><div style="text-align: center;">
<a href="index.php"><img src="image/logo.png"></a>
</div>
<h1>標體</h1>
<fieldset>
</fieldset>
<a href="19.php" class="myButton"><img src="image/Back.gif" width="20" height="20"> 上一篇:特殊字元與符號特輯</a> <a href="javascript:;" onclick="javascript:alertify.log('您已到最後一頁，會陸續增加，敬請期待。');" class="myButton" id="log-btn">下一篇:陸續增加，敬請期待 <img src="image/next.gif" width="20" height="20"></a>
</div>
<font size=5 color="#9900ff">
<marquee direction="up" behavior="slide" bgcolor="#8e7cc3">
<div style="text-align: center;">
聯絡我們<br /><a href="mailto:jochgvofd@gmail.com"> <img src="image/taddyshen.png" /><br /><a href="https://line.me/ti/p/%40trr7250q"><img height="36" border="0" alt="好友人數" src="http://biz.line.naver.jp/line_business/img/btn/addfriends_zh-Hant.png"></a><br /><a href="https://www.facebook.com/newjochgvofd">Facebook粉絲團<a><br />
© 2012-2015 <a href="http://jochgvofd.gq/" target="_blank">次是慶宇工作室</a> - © 2012-2015 <a href="http://wwww.wartw.tk/" target="_blank">風雨人多元工作室</a>合作</div>
</font>
</marquee>
</body>
</html>
</span>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<span style="font-family:Arial, Tahoma, Helvetica, FreeSans, Microsoft JhengHei, Heiti TC, TW-Kai, sans-serif;">
<html>
<head>
<title>次是慶宇HTML語法整理</title>
<style>
<link rel=stylesheet type="text/css" href="image/joch.css">
</head>
<body>
<p>
	<td><?php require_once('./image/header.php'); ?></td></p><div style="text-align: center;">
<a href="index.php"><img src="image/logo.png"></a>
</div>
<h1>加入背景圖像</h1>
<fieldset>
若您覺得背景顏色太單調，想要換成背景圖像的話，就得要在&lt;body&gt;內加入background的屬性了。如果你的背景圖檔檔名為 back.gif，則&lt;body&gt;內便要寫成 :<br />
	&lt;body <font color="#cc00cc">background</font>=&quot;<font color="#9900ff">back.gif</font>&quot; text=&quot;#000000&quot; link=&quot;#0066cc&quot; vlink=&quot;#336600&quot;&gt;<br />
PS:如果圖像的檔案跟您網頁的檔案不在同一目錄裡，則必須輸入完整路徑，如http://www.123.com.tw/back.gif。<br />
<font color="#cc00cc">bgproperties</font>=&quot;<font color="#9900ff">fixed</font>&quot;(使背景圖像固定不動，不過只有IE有效果)<br />
</fieldset>
<a href="4.php" class="myButton"><img src="image/Back.gif" width="20" height="20"> 上一篇:網頁顏色設定</a> <a href="6.php" class="myButton">下一篇:加入水平分線 <img src="image/next.gif" width="20" height="20"></a>
</div>
<font size=5 color="#9900ff">
<td><?php require_once('./image/len.php'); ?></td></font>
</body>
</html>
</span>
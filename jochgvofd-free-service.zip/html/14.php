<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<span style="font-family:Arial, Tahoma, Helvetica, FreeSans, Microsoft JhengHei, Heiti TC, TW-Kai, sans-serif;">
<html>
<head>
<title>次是慶宇HTML語法整理</title>
<link rel=stylesheet type="text/css" href="image/joch.css">
</head>
<body>
<p>
	<td><?php require_once('./image/header.php'); ?></td></p><div style="text-align: center;">
<a href="index.php"><img src="image/logo.png"></a>
</div>
<h1>插入圖片</h1>
<fieldset>
<div>
	圖像是一個美化網頁的重要因素，要插入圖像，就要加入<span style="color:#cc00cc;">&lt;img src=&quot;圖檔名&quot;&gt;</span></div>
<div>
	<span style="color:#cc00cc;">&lt;img src=&quot;http://joch.gq/free/html/image/logo.png&quot;&gt;</span></div>
<div>
	上面的碼會做出下面的效果 :</div>
<img src="http://joch.gq/free/html/image/logo.png">
<div>
	其中<span style="color:#cc00cc;">&lt;img src=&quot;**.gif&quot;&gt;</span>內還可加入下列屬性，來變化圖檔 :</div>
<div>
	<span style="color:#cc00cc;">width</span>=控制圖檔長度</div>
<div>
	<span style="color:#cc00cc;">height</span>=控制圖檔高度</div>
<div>
	<span style="color:#cc00cc;">align</span>=控制圖檔<span style="color:#9900ff;">left</span>(靠左)／<span style="color:#9900ff;">center</span>(置中)／<span style="color:#9900ff;">right</span>(靠右)</div>
<div>
	<span style="color:#cc00cc;">border</span>=控制外框粗細，不外框便設成0</div>
</fieldset>
<a href="13.php" class="myButton"><img src="image/Back.gif" width="20" height="20"> 上一篇:文件內的連結</a> <a href="15.php" class="myButton">下一篇:表格設定 <img src="image/next.gif" width="20" height="20"></a>
</div>
<font size=5 color="#9900ff">
<td><?php require_once('./image/len.php'); ?></td></font>
</body>
</html>
</span>
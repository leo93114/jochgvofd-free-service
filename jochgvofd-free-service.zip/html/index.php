<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<span style="font-family:Arial, Tahoma, Helvetica, FreeSans, Microsoft JhengHei, Heiti TC, TW-Kai, sans-serif;">
<html>
<head>
<link rel="shortcut icon" href="image/favicon.ico">
<title>次是慶宇HTML語法整理</title>
<link rel=stylesheet type="text/css" href="image/joch.css">
</head>
<body>
<p>
<font size=5 color="#fff">
<marquee onMouseOver="this.stop()" onMouseOut="this.start()" bgcolor="#9900ff">次是慶宇html教學網正式開放，請使用新版瀏覽器效果更好。</marquee></font>
	<a href="http://free.joch.gq/" class="myButton">更多免費服務</a> <a href="http://joch.gq/free/colorcobe" class="myButton">色碼表</a><!--[if lte IE 9]>
<center>
</p>
<p style="font-size: 16px;">
你目前使用舊版Internet Explorer瀏覽器，網頁會有異常哦
<p style="font-size: 16px;">
請換別的瀏覽器或更新IE瀏覽器以可獲得更好的體驗
<p><a href="http://www.google.com/chrome/" target="_blank"><img src="http://i.imgur.com/Ha8J2OQ.png" width="48" height="48" /></a> <a href="http://mozilla.com.tw/firefox/new/?utm_source=getfirefox-com&amp;utm_medium=referral" target="_blank"><img src="http://i.imgur.com/nb3Bx90.png" width="48" height="48" /></a> <a href="http://www.opera.com" target="_blank"><img src="http://i.imgur.com/qfywl6j.png" width="48" height="48" /></a> <a href="http://www.apple.com/cn/safari/" target="_blank"><img src="http://i.imgur.com/FSwXztz.png" width="48" height="48" /></a> <a href="http://windows.microsoft.com/zh-tw/internet-explorer/download-ie" target="_blank"><img src="http://i.imgur.com/vroljrQ.png" width="48" height="48" /></a></p>
</center>
</div>
<![endif]--></p>
<div style="text-align: center;">
<img src="image/logo.png">
<h2>
	教學導覽</h2>
<p>
	<a href="1.php" class="myButton">概述html</a></p>
<p>
	<a href="2.php" class="myButton">html的結構</a></p>
<p>
        <a href="3.php" class="myButton">解決網頁亂碼</a></p>
<p>
	<a href="4.php" class="myButton">網頁顏色設定</a></p>
<p>
	<a href="5.php" class="myButton">加入背景圖像</a></p>
<p>
	<a href="6.php" class="myButton">加入水平分線</a></p>
<p>
	<a href="7.php" class="myButton">清單設定方式</a></p>
<p>
	<a href="8.php" class="myButton">標題文字</a></p>
<p>
	<a href="9.php" class="myButton">文字設定</a></p>
<p>
	<a href="10.php" class="myButton">強迫換行</a></p>
<p>
	<a href="11.php" class="myButton">文字格式化</a></p>
<p>
	<a href="12.php" class="myButton">插入超連結</a></p>
<p>
	<a href="13.php" class="myButton">文件內的連結</a></p>
<p>
	<a href="14.php" class="myButton">插入圖片</a></p>
<p>
	<a href="15.php" class="myButton">表格設定</a></p>
<p>
	<a href="16.php" class="myButton">分割視窗</a></p>
<p>
	<a href="17.php" class="myButton">音樂語法</a></p>
<p>
	<a href="18.php" class="myButton">跑馬燈</a></p>
<p>
	<a href="19.php" class="myButton">特殊字元與符號特輯</a></p>
</div>
<font size=5 color="#9900ff">
<td><?php require_once('./image/len.php'); ?></td>
</body>
</html>
</span>
<a class="myButton" href="http://free.joch.gq/">更多免費服務</a> <a class="myButton" href="index.html">色碼表</a> <a class="myButton" href="colorcord2.html">背景色彩選擇器</a> <a class="myButton" href="colorcord1.html">色碼選擇器</a>
<a class="myButton" href="ColorTable.html">英文色碼表</a>
<a class="myButton" href="color-1.html">英文色碼表</a>
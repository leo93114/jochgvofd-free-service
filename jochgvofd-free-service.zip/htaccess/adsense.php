<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 尾端 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4999646866967900"
     data-ad-slot="9083437074"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
